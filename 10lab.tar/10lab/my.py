num = 1
while num < 10:
    print ("Hello")
